const Achievement = require('../models/Achievement');
const { recalculateCompletion } = require('./facultyController');

// @desc    Get all achievements for a faculty (self or by id for admin)
// @route   GET /api/achievements/:facultyId?
// @access  Private
const getAchievements = async (req, res, next) => {
  try {
    const facultyId = req.params.facultyId || req.user._id;
    const achievements = await Achievement.find({ facultyId }).sort({ year: -1 });
    res.status(200).json({ success: true, count: achievements.length, data: achievements });
  } catch (error) {
    next(error);
  }
};

// @desc    Add a new achievement
// @route   POST /api/achievements
// @access  Private
const addAchievement = async (req, res, next) => {
  try {
    const achievement = await Achievement.create({ ...req.body, facultyId: req.user._id });
    await recalculateCompletion(req.user._id);
    res.status(201).json({ success: true, data: achievement });
  } catch (error) {
    next(error);
  }
};

// @desc    Update an achievement
// @route   PUT /api/achievements/:id
// @access  Private
const updateAchievement = async (req, res, next) => {
  try {
    const achievement = await Achievement.findOne({ _id: req.params.id, facultyId: req.user._id });
    if (!achievement) return res.status(404).json({ success: false, message: 'Achievement not found' });

    Object.assign(achievement, req.body);
    await achievement.save();

    res.status(200).json({ success: true, data: achievement });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete an achievement
// @route   DELETE /api/achievements/:id
// @access  Private
const deleteAchievement = async (req, res, next) => {
  try {
    const achievement = await Achievement.findOneAndDelete({ _id: req.params.id, facultyId: req.user._id });
    if (!achievement) return res.status(404).json({ success: false, message: 'Achievement not found' });

    await recalculateCompletion(req.user._id);
    res.status(200).json({ success: true, message: 'Achievement deleted' });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAchievements, addAchievement, updateAchievement, deleteAchievement };
