const User = require('../models/User');
const FacultyProfile = require('../models/FacultyProfile');
const Certificate = require('../models/Certificate');
const Publication = require('../models/Publication');

// @desc    Get all faculty with search & filter support
// @route   GET /api/admin/faculty
// @access  Private/Admin
const getAllFaculty = async (req, res, next) => {
  try {
    const { search, department, designation, qualification, minExperience, page = 1, limit = 10 } = req.query;

    const query = { role: 'faculty' };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    if (department) query.department = department;
    if (designation) query.designation = designation;

    let facultyIds = null;
    if (qualification || minExperience) {
      const profileQuery = {};
      if (qualification) profileQuery.qualification = qualification;
      if (minExperience) profileQuery.experience = { $gte: Number(minExperience) };
      const matchingProfiles = await FacultyProfile.find(profileQuery).select('userId');
      facultyIds = matchingProfiles.map((p) => p.userId);
      query._id = { $in: facultyIds };
    }

    const total = await User.countDocuments(query);
    const faculty = await User.find(query)
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit))
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: faculty.length,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      data: faculty,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Edit a faculty user's core details
// @route   PUT /api/admin/faculty/:id
// @access  Private/Admin
const editFaculty = async (req, res, next) => {
  try {
    const { name, department, designation, phone, status, isVerified } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, department, designation, phone, status, isVerified },
      { new: true, runValidators: true }
    );
    if (!user) return res.status(404).json({ success: false, message: 'Faculty not found' });

    res.status(200).json({ success: true, data: user });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a faculty user and related data
// @route   DELETE /api/admin/faculty/:id
// @access  Private/Admin
const deleteFaculty = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'Faculty not found' });

    await Promise.all([
      FacultyProfile.deleteOne({ userId: user._id }),
      Certificate.deleteMany({ facultyId: user._id }),
      Publication.deleteMany({ facultyId: user._id }),
      user.deleteOne(),
    ]);

    res.status(200).json({ success: true, message: 'Faculty deleted successfully' });
  } catch (error) {
    next(error);
  }
};

// @desc    Get analytics data for admin dashboard
// @route   GET /api/admin/analytics
// @access  Private/Admin
const getAnalytics = async (req, res, next) => {
  try {
    const totalFaculty = await User.countDocuments({ role: 'faculty' });
    const verifiedFaculty = await User.countDocuments({ role: 'faculty', isVerified: true });
    const pendingVerification = totalFaculty - verifiedFaculty;

    const facultyPerDepartment = await User.aggregate([
      { $match: { role: 'faculty' } },
      { $group: { _id: '$department', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);

    const qualificationDistribution = await FacultyProfile.aggregate([
      { $group: { _id: '$qualification', count: { $sum: 1 } } },
    ]);

    const certificateStats = await Certificate.aggregate([
      { $group: { _id: '$verificationStatus', count: { $sum: 1 } } },
    ]);

    const avgProfileCompletion = await User.aggregate([
      { $match: { role: 'faculty' } },
      { $group: { _id: null, avg: { $avg: '$profileCompletion' } } },
    ]);

    const publicationsPerDepartment = await Publication.aggregate([
      { $lookup: { from: 'users', localField: 'facultyId', foreignField: '_id', as: 'faculty' } },
      { $unwind: '$faculty' },
      { $group: { _id: '$faculty.department', count: { $sum: 1 } } },
    ]);

    const recentFaculty = await User.find({ role: 'faculty' }).sort({ createdAt: -1 }).limit(5);

    res.status(200).json({
      success: true,
      data: {
        totalFaculty,
        verifiedFaculty,
        pendingVerification,
        departmentsCount: facultyPerDepartment.length,
        facultyPerDepartment,
        qualificationDistribution,
        certificateStats,
        avgProfileCompletion: avgProfileCompletion[0]?.avg || 0,
        publicationsPerDepartment,
        recentFaculty,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllFaculty, editFaculty, deleteFaculty, getAnalytics };
