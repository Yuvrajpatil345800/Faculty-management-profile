const Publication = require('../models/Publication');
const { recalculateCompletion } = require('./facultyController');

// @desc    Get all publications for a faculty (self or by id for admin)
// @route   GET /api/publications/:facultyId?
// @access  Private
const getPublications = async (req, res, next) => {
  try {
    const facultyId = req.params.facultyId || req.user._id;
    const { search } = req.query;

    const query = { facultyId };
    if (search) {
      query.$text = { $search: search };
    }

    const publications = await Publication.find(query).sort({ year: -1 });
    res.status(200).json({ success: true, count: publications.length, data: publications });
  } catch (error) {
    next(error);
  }
};

// @desc    Add a new publication
// @route   POST /api/publications
// @access  Private
const addPublication = async (req, res, next) => {
  try {
    const publication = await Publication.create({ ...req.body, facultyId: req.user._id });
    await recalculateCompletion(req.user._id);
    res.status(201).json({ success: true, data: publication });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a publication
// @route   PUT /api/publications/:id
// @access  Private
const updatePublication = async (req, res, next) => {
  try {
    const publication = await Publication.findOne({ _id: req.params.id, facultyId: req.user._id });
    if (!publication) return res.status(404).json({ success: false, message: 'Publication not found' });

    Object.assign(publication, req.body);
    await publication.save();

    res.status(200).json({ success: true, data: publication });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a publication
// @route   DELETE /api/publications/:id
// @access  Private
const deletePublication = async (req, res, next) => {
  try {
    const publication = await Publication.findOneAndDelete({ _id: req.params.id, facultyId: req.user._id });
    if (!publication) return res.status(404).json({ success: false, message: 'Publication not found' });

    await recalculateCompletion(req.user._id);
    res.status(200).json({ success: true, message: 'Publication deleted' });
  } catch (error) {
    next(error);
  }
};

module.exports = { getPublications, addPublication, updatePublication, deletePublication };
