const User = require('../models/User');
const FacultyProfile = require('../models/FacultyProfile');
const Publication = require('../models/Publication');
const Certificate = require('../models/Certificate');
const Achievement = require('../models/Achievement');
const { cloudinary } = require('../config/cloudinary');

// Recalculates and persists the profile completion percentage for a user
const recalculateCompletion = async (userId) => {
  const user = await User.findById(userId);
  const profile = await FacultyProfile.findOne({ userId });
  const pubCount = await Publication.countDocuments({ facultyId: userId });
  const certCount = await Certificate.countDocuments({ facultyId: userId });
  const achCount = await Achievement.countDocuments({ facultyId: userId });

  let score = 0;
  const weight = 100 / 8;

  if (user?.profilePhoto?.url) score += weight;
  if (user?.phone) score += weight;
  if (profile?.qualification && profile.qualification !== 'Other') score += weight;
  if (profile?.specialization) score += weight;
  if (profile?.biography) score += weight;
  if (profile?.researchInterest?.length > 0) score += weight;
  if (pubCount > 0) score += weight;
  if (certCount > 0 || achCount > 0) score += weight;

  const completion = Math.min(100, Math.round(score));
  await User.findByIdAndUpdate(userId, { profileCompletion: completion });
  return completion;
};

// @desc    Get full faculty profile (self or by id for admin)
// @route   GET /api/faculty/profile/:id?
// @access  Private
const getFacultyProfile = async (req, res, next) => {
  try {
    const targetId = req.params.id || req.user._id;

    // Faculty may only view their own profile; admin can view any
    if (req.user.role !== 'admin' && String(targetId) !== String(req.user._id)) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    const user = await User.findById(targetId);
    if (!user) return res.status(404).json({ success: false, message: 'Faculty not found' });

    const profile = await FacultyProfile.findOne({ userId: targetId });
    const publications = await Publication.find({ facultyId: targetId }).sort({ year: -1 });
    const certificates = await Certificate.find({ facultyId: targetId }).sort({ createdAt: -1 });
    const achievements = await Achievement.find({ facultyId: targetId }).sort({ year: -1 });

    res.status(200).json({ success: true, data: { user, profile, publications, certificates, achievements } });
  } catch (error) {
    next(error);
  }
};

// @desc    Update personal details (name, phone, department, designation)
// @route   PUT /api/faculty/personal
// @access  Private
const updatePersonalDetails = async (req, res, next) => {
  try {
    const { name, phone, department, designation } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { name, phone, department, designation },
      { new: true, runValidators: true }
    );
    await recalculateCompletion(req.user._id);
    res.status(200).json({ success: true, data: user });
  } catch (error) {
    next(error);
  }
};

// @desc    Update academic/professional profile details
// @route   PUT /api/faculty/academic
// @access  Private
const updateAcademicDetails = async (req, res, next) => {
  try {
    const { qualification, specialization, experience, researchInterest, biography, address, education, workExperience } = req.body;

    const profile = await FacultyProfile.findOneAndUpdate(
      { userId: req.user._id },
      { qualification, specialization, experience, researchInterest, biography, address, education, workExperience },
      { new: true, upsert: true, runValidators: true }
    );

    await recalculateCompletion(req.user._id);
    res.status(200).json({ success: true, data: profile });
  } catch (error) {
    next(error);
  }
};

// @desc    Upload/replace profile photo
// @route   POST /api/faculty/photo
// @access  Private
const uploadProfilePhoto = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    const user = await User.findById(req.user._id);

    // Delete old photo from Cloudinary if it exists
    if (user.profilePhoto?.publicId) {
      await cloudinary.uploader.destroy(user.profilePhoto.publicId);
    }

    user.profilePhoto = { url: req.file.path, publicId: req.file.filename };
    await user.save();

    await recalculateCompletion(req.user._id);
    res.status(200).json({ success: true, data: user.profilePhoto });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getFacultyProfile,
  updatePersonalDetails,
  updateAcademicDetails,
  uploadProfilePhoto,
  recalculateCompletion,
};
