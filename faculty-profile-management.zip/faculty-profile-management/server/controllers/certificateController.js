const Certificate = require('../models/Certificate');
const { cloudinary } = require('../config/cloudinary');
const { recalculateCompletion } = require('./facultyController');

// @desc    Get all certificates for a faculty (self or by id for admin)
// @route   GET /api/certificates/:facultyId?
// @access  Private
const getCertificates = async (req, res, next) => {
  try {
    const facultyId = req.params.facultyId || req.user._id;
    const certificates = await Certificate.find({ facultyId }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: certificates.length, data: certificates });
  } catch (error) {
    next(error);
  }
};

// @desc    Upload a new certificate (image or PDF)
// @route   POST /api/certificates
// @access  Private
const uploadCertificate = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    const { certificateName } = req.body;
    const fileType = req.file.mimetype === 'application/pdf' ? 'pdf' : 'image';

    const certificate = await Certificate.create({
      facultyId: req.user._id,
      certificateName,
      cloudinaryUrl: req.file.path,
      cloudinaryPublicId: req.file.filename,
      fileType,
    });

    await recalculateCompletion(req.user._id);
    res.status(201).json({ success: true, data: certificate });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a certificate
// @route   DELETE /api/certificates/:id
// @access  Private
const deleteCertificate = async (req, res, next) => {
  try {
    const certificate = await Certificate.findOne({ _id: req.params.id, facultyId: req.user._id });
    if (!certificate) return res.status(404).json({ success: false, message: 'Certificate not found' });

    await cloudinary.uploader.destroy(certificate.cloudinaryPublicId, {
      resource_type: certificate.fileType === 'pdf' ? 'raw' : 'image',
    });
    await certificate.deleteOne();

    res.status(200).json({ success: true, message: 'Certificate deleted' });
  } catch (error) {
    next(error);
  }
};

// @desc    Verify/reject a certificate (admin only)
// @route   PUT /api/certificates/:id/verify
// @access  Private/Admin
const verifyCertificate = async (req, res, next) => {
  try {
    const { verificationStatus, remarks } = req.body;
    if (!['approved', 'rejected', 'pending'].includes(verificationStatus)) {
      return res.status(400).json({ success: false, message: 'Invalid verification status' });
    }

    const certificate = await Certificate.findByIdAndUpdate(
      req.params.id,
      { verificationStatus, remarks },
      { new: true }
    );
    if (!certificate) return res.status(404).json({ success: false, message: 'Certificate not found' });

    res.status(200).json({ success: true, data: certificate });
  } catch (error) {
    next(error);
  }
};

module.exports = { getCertificates, uploadCertificate, deleteCertificate, verifyCertificate };
