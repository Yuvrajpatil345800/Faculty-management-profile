const User = require('../models/User');
const FacultyProfile = require('../models/FacultyProfile');
const Publication = require('../models/Publication');
const Certificate = require('../models/Certificate');
const Achievement = require('../models/Achievement');
const generateFacultyPDF = require('../utils/pdfGenerator');
const exportFacultyToCSV = require('../utils/csvExporter');

// @desc    Download a faculty profile as a PDF
// @route   GET /api/reports/faculty-pdf/:id?
// @access  Private
const downloadFacultyPDF = async (req, res, next) => {
  try {
    const targetId = req.params.id || req.user._id;

    if (req.user.role !== 'admin' && String(targetId) !== String(req.user._id)) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    const user = await User.findById(targetId);
    if (!user) return res.status(404).json({ success: false, message: 'Faculty not found' });

    const profile = await FacultyProfile.findOne({ userId: targetId });
    const publications = await Publication.find({ facultyId: targetId });
    const certificates = await Certificate.find({ facultyId: targetId });
    const achievements = await Achievement.find({ facultyId: targetId });

    generateFacultyPDF(res, { user, profile, publications, achievements, certificates });
  } catch (error) {
    next(error);
  }
};

// @desc    Generate a department-wise report (JSON summary)
// @route   GET /api/reports/department/:dept
// @access  Private/Admin
const generateDepartmentReport = async (req, res, next) => {
  try {
    const { dept } = req.params;
    const facultyList = await User.find({ role: 'faculty', department: dept });

    const report = await Promise.all(
      facultyList.map(async (f) => {
        const pubCount = await Publication.countDocuments({ facultyId: f._id });
        const certCount = await Certificate.countDocuments({ facultyId: f._id });
        return {
          name: f.name,
          designation: f.designation,
          profileCompletion: f.profileCompletion,
          isVerified: f.isVerified,
          publications: pubCount,
          certificates: certCount,
        };
      })
    );

    res.status(200).json({ success: true, department: dept, count: report.length, data: report });
  } catch (error) {
    next(error);
  }
};

// @desc    Export all faculty as CSV
// @route   GET /api/reports/export-csv
// @access  Private/Admin
const exportCSV = async (req, res, next) => {
  try {
    const facultyList = await User.find({ role: 'faculty' }).lean();
    const csv = exportFacultyToCSV(facultyList);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=faculty_report.csv');
    res.status(200).send(csv);
  } catch (error) {
    next(error);
  }
};

module.exports = { downloadFacultyPDF, generateDepartmentReport, exportCSV };
