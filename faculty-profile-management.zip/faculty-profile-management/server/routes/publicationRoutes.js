const express = require('express');
const {
  getPublications,
  addPublication,
  updatePublication,
  deletePublication,
} = require('../controllers/publicationController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.get('/:facultyId?', getPublications);
router.post('/', addPublication);
router.put('/:id', updatePublication);
router.delete('/:id', deletePublication);

module.exports = router;
