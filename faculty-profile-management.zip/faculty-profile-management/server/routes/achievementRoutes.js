const express = require('express');
const {
  getAchievements,
  addAchievement,
  updateAchievement,
  deleteAchievement,
} = require('../controllers/achievementController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.get('/:facultyId?', getAchievements);
router.post('/', addAchievement);
router.put('/:id', updateAchievement);
router.delete('/:id', deleteAchievement);

module.exports = router;
