const express = require('express');
const { downloadFacultyPDF, generateDepartmentReport, exportCSV } = require('../controllers/reportController');
const { protect } = require('../middleware/auth');
const authorizeRoles = require('../middleware/roleMiddleware');

const router = express.Router();

router.use(protect);

router.get('/faculty-pdf/:id?', downloadFacultyPDF);
router.get('/department/:dept', authorizeRoles('admin'), generateDepartmentReport);
router.get('/export-csv', authorizeRoles('admin'), exportCSV);

module.exports = router;
