const express = require('express');
const {
  getFacultyProfile,
  updatePersonalDetails,
  updateAcademicDetails,
  uploadProfilePhoto,
} = require('../controllers/facultyController');
const { protect } = require('../middleware/auth');
const { uploadProfilePhoto: uploadPhotoMiddleware } = require('../middleware/upload');

const router = express.Router();

router.use(protect);

router.get('/profile/:id?', getFacultyProfile);
router.put('/personal', updatePersonalDetails);
router.put('/academic', updateAcademicDetails);
router.post('/photo', uploadPhotoMiddleware.single('photo'), uploadProfilePhoto);

module.exports = router;
