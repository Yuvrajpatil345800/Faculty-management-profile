const express = require('express');
const {
  getCertificates,
  uploadCertificate,
  deleteCertificate,
  verifyCertificate,
} = require('../controllers/certificateController');
const { protect } = require('../middleware/auth');
const authorizeRoles = require('../middleware/roleMiddleware');
const { uploadCertificate: uploadCertMiddleware } = require('../middleware/upload');

const router = express.Router();

router.use(protect);

router.get('/:facultyId?', getCertificates);
router.post('/', uploadCertMiddleware.single('certificate'), uploadCertificate);
router.delete('/:id', deleteCertificate);
router.put('/:id/verify', authorizeRoles('admin'), verifyCertificate);

module.exports = router;
