const express = require('express');
const { getAllFaculty, editFaculty, deleteFaculty, getAnalytics } = require('../controllers/adminController');
const { protect } = require('../middleware/auth');
const authorizeRoles = require('../middleware/roleMiddleware');

const router = express.Router();

router.use(protect, authorizeRoles('admin'));

router.get('/faculty', getAllFaculty);
router.put('/faculty/:id', editFaculty);
router.delete('/faculty/:id', deleteFaculty);
router.get('/analytics', getAnalytics);

module.exports = router;
