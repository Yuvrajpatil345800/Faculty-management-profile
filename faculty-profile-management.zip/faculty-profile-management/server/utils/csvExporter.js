const { Parser } = require('json2csv');

// Converts an array of faculty records to CSV format for admin export
const exportFacultyToCSV = (facultyList) => {
  const fields = [
    { label: 'Name', value: 'name' },
    { label: 'Email', value: 'email' },
    { label: 'Department', value: 'department' },
    { label: 'Designation', value: 'designation' },
    { label: 'Phone', value: 'phone' },
    { label: 'Profile Completion (%)', value: 'profileCompletion' },
    { label: 'Verified', value: 'isVerified' },
    { label: 'Status', value: 'status' },
  ];
  const parser = new Parser({ fields });
  return parser.parse(facultyList);
};

module.exports = exportFacultyToCSV;
