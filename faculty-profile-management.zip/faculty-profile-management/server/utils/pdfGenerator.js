const PDFDocument = require('pdfkit');

// Streams a faculty profile as a formatted PDF document to the response
const generateFacultyPDF = (res, { user, profile, publications, achievements, certificates }) => {
  const doc = new PDFDocument({ margin: 50 });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename=${user.name.replace(/\s+/g, '_')}_profile.pdf`);

  doc.pipe(res);

  // Header
  doc.fontSize(20).fillColor('#1e3a8a').text('Faculty Profile', { align: 'center' });
  doc.moveDown();
  doc.fontSize(14).fillColor('#000').text(user.name, { align: 'center' });
  doc.fontSize(11).fillColor('#555').text(`${user.designation} - ${user.department}`, { align: 'center' });
  doc.moveDown(1.5);

  const section = (title) => {
    doc.fontSize(13).fillColor('#1e3a8a').text(title, { underline: true });
    doc.moveDown(0.5);
    doc.fontSize(10).fillColor('#000');
  };

  section('Contact Information');
  doc.text(`Email: ${user.email}`);
  doc.text(`Phone: ${user.phone || 'N/A'}`);
  doc.moveDown();

  section('Academic Details');
  doc.text(`Qualification: ${profile?.qualification || 'N/A'}`);
  doc.text(`Specialization: ${profile?.specialization || 'N/A'}`);
  doc.text(`Experience: ${profile?.experience || 0} years`);
  doc.moveDown();

  if (profile?.biography) {
    section('Biography');
    doc.text(profile.biography, { align: 'justify' });
    doc.moveDown();
  }

  section('Publications');
  if (publications && publications.length > 0) {
    publications.forEach((pub, i) => {
      doc.text(`${i + 1}. ${pub.title} - ${pub.journal || pub.publisher || ''} (${pub.year})`);
    });
  } else {
    doc.text('No publications added.');
  }
  doc.moveDown();

  section('Achievements');
  if (achievements && achievements.length > 0) {
    achievements.forEach((a, i) => {
      doc.text(`${i + 1}. ${a.title} (${a.year}) - ${a.description || ''}`);
    });
  } else {
    doc.text('No achievements added.');
  }
  doc.moveDown();

  section('Certificates');
  if (certificates && certificates.length > 0) {
    certificates.forEach((c, i) => {
      doc.text(`${i + 1}. ${c.certificateName} [${c.verificationStatus.toUpperCase()}]`);
    });
  } else {
    doc.text('No certificates uploaded.');
  }

  doc.end();
};

module.exports = generateFacultyPDF;
