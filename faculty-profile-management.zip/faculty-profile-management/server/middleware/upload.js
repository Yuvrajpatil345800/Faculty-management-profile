const multer = require('multer');
const { profilePhotoStorage, certificateStorage } = require('../config/cloudinary');

// Multer instance for profile photo uploads (single image)
const uploadProfilePhoto = multer({
  storage: profilePhotoStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

// Multer instance for certificate uploads (image or PDF)
const uploadCertificate = multer({
  storage: certificateStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

module.exports = { uploadProfilePhoto, uploadCertificate };
