const mongoose = require('mongoose');

const publicationSchema = new mongoose.Schema(
  {
    facultyId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: [true, 'Title is required'], trim: true },
    journal: { type: String, trim: true },
    publisher: { type: String, trim: true },
    year: { type: Number, required: true },
    doi: { type: String, trim: true, default: '' },
    type: { type: String, enum: ['Journal', 'Conference', 'Book Chapter', 'Book'], default: 'Journal' },
  },
  { timestamps: true }
);

publicationSchema.index({ title: 'text', journal: 'text' });

module.exports = mongoose.model('Publication', publicationSchema);
