const mongoose = require('mongoose');

const facultyProfileSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    qualification: {
      type: String,
      enum: ['PhD', 'M.Tech', 'M.E', 'M.Sc', 'MBA', 'B.Tech', 'B.E', 'Other'],
      default: 'Other',
    },
    specialization: { type: String, trim: true, default: '' },
    experience: { type: Number, default: 0, min: 0 }, // years of experience
    researchInterest: [{ type: String, trim: true }],
    biography: { type: String, trim: true, maxlength: 2000, default: '' },
    address: { type: String, trim: true, default: '' },
    education: [
      {
        degree: { type: String, trim: true },
        institution: { type: String, trim: true },
        year: { type: Number },
      },
    ],
    workExperience: [
      {
        organization: { type: String, trim: true },
        designation: { type: String, trim: true },
        from: { type: Number },
        to: { type: Number },
        description: { type: String, trim: true },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('FacultyProfile', facultyProfileSchema);
