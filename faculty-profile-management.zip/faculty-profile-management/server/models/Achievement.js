const mongoose = require('mongoose');

const achievementSchema = new mongoose.Schema(
  {
    facultyId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: [true, 'Title is required'], trim: true },
    description: { type: String, trim: true, default: '' },
    year: { type: Number, required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Achievement', achievementSchema);
