import { Routes, Route, Navigate } from 'react-router-dom';
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute';
import useAuth from './hooks/useAuth';

import Login from './pages/Login';
import Register from './pages/Register';
import FacultyDashboard from './pages/FacultyDashboard';
import Profile from './pages/Profile';
import Publications from './pages/Publications';
import Certificates from './pages/Certificates';
import Achievements from './pages/Achievements';
import AdminDashboard from './pages/AdminDashboard';
import AdminFacultyList from './pages/AdminFacultyList';
import AdminFacultyDetail from './pages/AdminFacultyDetail';
import AdminReports from './pages/AdminReports';
import NotFound from './pages/NotFound';

// Root application router - defines public auth routes and protected dashboard routes
const App = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Root redirect */}
      <Route
        path="/"
        element={<Navigate to={user ? (user.role === 'admin' ? '/admin/dashboard' : '/dashboard') : '/login'} replace />}
      />

      {/* Public auth routes */}
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>

      {/* Faculty routes */}
      <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<FacultyDashboard />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/publications" element={<Publications />} />
        <Route path="/certificates" element={<Certificates />} />
        <Route path="/achievements" element={<Achievements />} />
      </Route>

      {/* Admin routes */}
      <Route element={<ProtectedRoute requiredRole="admin"><DashboardLayout /></ProtectedRoute>}>
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/faculty" element={<AdminFacultyList />} />
        <Route path="/admin/faculty/:id" element={<AdminFacultyDetail />} />
        <Route path="/admin/reports" element={<AdminReports />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
