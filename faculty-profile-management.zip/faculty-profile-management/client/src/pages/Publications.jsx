import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiSearch, FiBookOpen } from 'react-icons/fi';
import api from '../services/api';
import Spinner from '../components/Spinner';
import EmptyState from '../components/EmptyState';
import Modal from '../components/Modal';

// Faculty publications CRUD page
const Publications = () => {
  const [publications, setPublications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  const fetchPublications = async (q = '') => {
    setLoading(true);
    try {
      const { data } = await api.get('/publications', { params: q ? { search: q } : {} });
      setPublications(data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPublications();
  }, []);

  const openAddModal = () => {
    setEditing(null);
    reset({ title: '', journal: '', publisher: '', year: '', doi: '', type: 'Journal' });
    setModalOpen(true);
  };

  const openEditModal = (pub) => {
    setEditing(pub);
    reset(pub);
    setModalOpen(true);
  };

  const onSubmit = async (formData) => {
    try {
      if (editing) {
        await api.put(`/publications/${editing._id}`, formData);
        toast.success('Publication updated');
      } else {
        await api.post('/publications', formData);
        toast.success('Publication added');
      }
      setModalOpen(false);
      fetchPublications(search);
    } catch (error) {
      toast.error(error.response?.data?.message || 'Save failed');
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this publication?')) return;
    try {
      await api.delete(`/publications/${id}`);
      toast.success('Publication deleted');
      fetchPublications(search);
    } catch (error) {
      toast.error('Delete failed');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-bold">Publications</h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="input-field pl-9"
              placeholder="Search publications..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                fetchPublications(e.target.value);
              }}
            />
          </div>
          <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
            <FiPlus /> Add
          </button>
        </div>
      </div>

      <div className="card p-0 overflow-x-auto">
        {loading ? (
          <Spinner size="lg" />
        ) : publications.length === 0 ? (
          <EmptyState title="No publications yet" subtitle="Add your first research publication." icon={FiBookOpen} />
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700 text-left">
              <tr>
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">Journal/Publisher</th>
                <th className="px-4 py-3">Year</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {publications.map((pub) => (
                <tr key={pub._id} className="border-t border-gray-100 dark:border-gray-700">
                  <td className="px-4 py-3 font-medium">{pub.title}</td>
                  <td className="px-4 py-3 text-gray-500">{pub.journal || pub.publisher || '-'}</td>
                  <td className="px-4 py-3">{pub.year}</td>
                  <td className="px-4 py-3">{pub.type}</td>
                  <td className="px-4 py-3 text-right space-x-2">
                    <button onClick={() => openEditModal(pub)} className="text-primary-600 hover:text-primary-800">
                      <FiEdit2 className="inline" />
                    </button>
                    <button onClick={() => onDelete(pub._id)} className="text-red-500 hover:text-red-700">
                      <FiTrash2 className="inline" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Publication' : 'Add Publication'}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="label">Title</label>
            <input className="input-field" {...register('title', { required: 'Title is required' })} />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Journal</label>
              <input className="input-field" {...register('journal')} />
            </div>
            <div>
              <label className="label">Publisher</label>
              <input className="input-field" {...register('publisher')} />
            </div>
            <div>
              <label className="label">Year</label>
              <input type="number" className="input-field" {...register('year', { required: true })} />
            </div>
            <div>
              <label className="label">Type</label>
              <select className="input-field" {...register('type')}>
                <option>Journal</option>
                <option>Conference</option>
                <option>Book Chapter</option>
                <option>Book</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label">DOI (optional)</label>
            <input className="input-field" {...register('doi')} />
          </div>
          <button type="submit" className="btn-primary w-full">{editing ? 'Update' : 'Add'} Publication</button>
        </form>
      </Modal>
    </div>
  );
};

export default Publications;
