import { useEffect, useState } from 'react';
import { FiUser, FiBookOpen, FiFileText, FiAward } from 'react-icons/fi';
import api from '../services/api';
import useAuth from '../hooks/useAuth';
import Card from '../components/Card';
import Spinner from '../components/Spinner';
import ProfileCompletionBar from '../components/ProfileCompletionBar';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';

// Faculty landing dashboard: welcome card, completion, quick stats, recent uploads
const FacultyDashboard = () => {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data: res } = await api.get('/faculty/profile');
        setData(res.data);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  if (loading) return <Spinner size="lg" />;

  const { user: freshUser, publications = [], certificates = [], achievements = [] } = data || {};

  return (
    <div className="space-y-6">
      {/* Welcome Card */}
      <div className="card bg-gradient-to-r from-primary-600 to-primary-800 text-white">
        <h2 className="text-xl font-bold">Welcome back, {user?.name}! 👋</h2>
        <p className="text-primary-100 text-sm mt-1">
          {freshUser?.designation} • {freshUser?.department}
        </p>
        <div className="mt-4 max-w-sm">
          <ProfileCompletionBar percentage={freshUser?.profileCompletion || 0} />
        </div>
      </div>

      {/* Quick Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card title="Publications" value={publications.length} icon={FiBookOpen} color="primary" />
        <Card title="Certificates" value={certificates.length} icon={FiFileText} color="green" />
        <Card title="Achievements" value={achievements.length} icon={FiAward} color="yellow" />
        <Card
          title="Verification"
          value={freshUser?.isVerified ? 'Verified' : 'Pending'}
          icon={FiUser}
          color={freshUser?.isVerified ? 'green' : 'red'}
        />
      </div>

      {/* Recent Uploads */}
      <div className="card">
        <h3 className="font-semibold mb-4">Recent Certificate Uploads</h3>
        {certificates.length === 0 ? (
          <EmptyState title="No certificates yet" subtitle="Upload your first certificate to get verified." icon={FiFileText} />
        ) : (
          <div className="space-y-3">
            {certificates.slice(0, 5).map((c) => (
              <div key={c._id} className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700 last:border-0">
                <span className="text-sm font-medium">{c.certificateName}</span>
                <StatusBadge status={c.verificationStatus} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FacultyDashboard;
