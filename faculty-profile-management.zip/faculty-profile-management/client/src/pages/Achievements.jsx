import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { FiPlus, FiTrash2, FiEdit2, FiAward } from 'react-icons/fi';
import api from '../services/api';
import Spinner from '../components/Spinner';
import EmptyState from '../components/EmptyState';
import Modal from '../components/Modal';

// Faculty achievements CRUD page
const Achievements = () => {
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  const fetchAchievements = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/achievements');
      setAchievements(data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAchievements();
  }, []);

  const openAddModal = () => {
    setEditing(null);
    reset({ title: '', description: '', year: '' });
    setModalOpen(true);
  };

  const openEditModal = (a) => {
    setEditing(a);
    reset(a);
    setModalOpen(true);
  };

  const onSubmit = async (formData) => {
    try {
      if (editing) {
        await api.put(`/achievements/${editing._id}`, formData);
        toast.success('Achievement updated');
      } else {
        await api.post('/achievements', formData);
        toast.success('Achievement added');
      }
      setModalOpen(false);
      fetchAchievements();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Save failed');
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this achievement?')) return;
    try {
      await api.delete(`/achievements/${id}`);
      toast.success('Achievement deleted');
      fetchAchievements();
    } catch (error) {
      toast.error('Delete failed');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Achievements</h2>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <FiPlus /> Add Achievement
        </button>
      </div>

      {loading ? (
        <Spinner size="lg" />
      ) : achievements.length === 0 ? (
        <div className="card">
          <EmptyState title="No achievements yet" subtitle="Add awards, honors, or recognitions." icon={FiAward} />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((a) => (
            <div key={a._id} className="card">
              <div className="flex items-start justify-between">
                <FiAward className="text-yellow-500" size={22} />
                <div className="flex gap-2">
                  <button onClick={() => openEditModal(a)} className="text-primary-600"><FiEdit2 size={14} /></button>
                  <button onClick={() => onDelete(a._id)} className="text-red-500"><FiTrash2 size={14} /></button>
                </div>
              </div>
              <h4 className="font-semibold mt-2">{a.title}</h4>
              <p className="text-xs text-gray-400 mb-1">{a.year}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{a.description}</p>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Achievement' : 'Add Achievement'}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="label">Title</label>
            <input className="input-field" {...register('title', { required: 'Title is required' })} />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title.message}</p>}
          </div>
          <div>
            <label className="label">Year</label>
            <input type="number" className="input-field" {...register('year', { required: true })} />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea rows="3" className="input-field" {...register('description')} />
          </div>
          <button type="submit" className="btn-primary w-full">{editing ? 'Update' : 'Add'} Achievement</button>
        </form>
      </Modal>
    </div>
  );
};

export default Achievements;
