import { useEffect, useState } from 'react';
import { FiUsers, FiCheckCircle, FiClock, FiGrid } from 'react-icons/fi';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import api from '../services/api';
import Card from '../components/Card';
import Spinner from '../components/Spinner';

const COLORS = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16'];

// Admin analytics dashboard with cards and charts
const AdminDashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const { data } = await api.get('/admin/analytics');
        setAnalytics(data.data);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  if (loading) return <Spinner size="lg" />;
  if (!analytics) return null;

  const {
    totalFaculty,
    verifiedFaculty,
    pendingVerification,
    departmentsCount,
    facultyPerDepartment,
    qualificationDistribution,
    certificateStats,
    avgProfileCompletion,
    recentFaculty,
  } = analytics;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Analytics Dashboard</h2>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card title="Total Faculty" value={totalFaculty} icon={FiUsers} color="primary" />
        <Card title="Verified Faculty" value={verifiedFaculty} icon={FiCheckCircle} color="green" />
        <Card title="Pending Verification" value={pendingVerification} icon={FiClock} color="yellow" />
        <Card title="Departments" value={departmentsCount} icon={FiGrid} color="primary" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Faculty per Department */}
        <div className="card">
          <h3 className="font-semibold mb-4">Faculty per Department</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={facultyPerDepartment}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="_id" tick={{ fontSize: 10 }} angle={-20} textAnchor="end" height={60} />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Qualification Distribution */}
        <div className="card">
          <h3 className="font-semibold mb-4">Qualification Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={qualificationDistribution} dataKey="count" nameKey="_id" outerRadius={90} label>
                {qualificationDistribution.map((entry, index) => (
                  <Cell key={index} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Pending vs Approved Certificates */}
        <div className="card">
          <h3 className="font-semibold mb-4">Certificate Status</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={certificateStats} dataKey="count" nameKey="_id" outerRadius={90} label>
                {certificateStats.map((entry, index) => (
                  <Cell key={index} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Average Profile Completion */}
        <div className="card flex flex-col items-center justify-center">
          <h3 className="font-semibold mb-4 self-start">Average Profile Completion</h3>
          <div className="text-5xl font-bold text-primary-600">{Math.round(avgProfileCompletion)}%</div>
          <p className="text-sm text-gray-400 mt-2">Across all faculty members</p>
        </div>
      </div>

      {/* Recent Faculty */}
      <div className="card">
        <h3 className="font-semibold mb-4">Recently Registered Faculty</h3>
        <table className="w-full text-sm">
          <thead className="text-left text-gray-500 dark:text-gray-400">
            <tr>
              <th className="py-2">Name</th>
              <th className="py-2">Department</th>
              <th className="py-2">Joined</th>
            </tr>
          </thead>
          <tbody>
            {recentFaculty.map((f) => (
              <tr key={f._id} className="border-t border-gray-100 dark:border-gray-700">
                <td className="py-2 font-medium">{f.name}</td>
                <td className="py-2">{f.department}</td>
                <td className="py-2 text-gray-400">{new Date(f.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
