import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { FiUpload, FiTrash2, FiFileText, FiExternalLink } from 'react-icons/fi';
import api from '../services/api';
import Spinner from '../components/Spinner';
import EmptyState from '../components/EmptyState';
import StatusBadge from '../components/StatusBadge';

// Faculty certificate upload & management page
const Certificates = () => {
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const { register, handleSubmit, reset } = useForm();

  const fetchCertificates = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/certificates');
      setCertificates(data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const onSubmit = async (formData) => {
    if (!formData.file || formData.file.length === 0) {
      toast.error('Please select a file');
      return;
    }
    const fd = new FormData();
    fd.append('certificateName', formData.certificateName);
    fd.append('certificate', formData.file[0]);

    setUploading(true);
    try {
      await api.post('/certificates', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Certificate uploaded');
      reset();
      fetchCertificates();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this certificate?')) return;
    try {
      await api.delete(`/certificates/${id}`);
      toast.success('Certificate deleted');
      fetchCertificates();
    } catch (error) {
      toast.error('Delete failed');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Certificates</h2>

      {/* Upload form */}
      <form onSubmit={handleSubmit(onSubmit)} className="card flex flex-col sm:flex-row gap-4 items-end">
        <div className="flex-1 w-full">
          <label className="label">Certificate Name</label>
          <input className="input-field" placeholder="e.g. AWS Certified Cloud Practitioner" {...register('certificateName', { required: true })} />
        </div>
        <div className="flex-1 w-full">
          <label className="label">File (image or PDF)</label>
          <input type="file" accept="image/*,application/pdf" className="input-field" {...register('file', { required: true })} />
        </div>
        <button type="submit" disabled={uploading} className="btn-primary flex items-center gap-2 whitespace-nowrap">
          <FiUpload /> {uploading ? 'Uploading...' : 'Upload'}
        </button>
      </form>

      {/* Certificate list */}
      <div className="card p-0">
        {loading ? (
          <Spinner size="lg" />
        ) : certificates.length === 0 ? (
          <EmptyState title="No certificates uploaded" subtitle="Upload a certificate to begin verification." icon={FiFileText} />
        ) : (
          <ul className="divide-y divide-gray-100 dark:divide-gray-700">
            {certificates.map((c) => (
              <li key={c._id} className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <FiFileText className="text-primary-600" size={20} />
                  <div>
                    <p className="font-medium text-sm">{c.certificateName}</p>
                    <p className="text-xs text-gray-400">{new Date(c.uploadDate).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <StatusBadge status={c.verificationStatus} />
                  <a href={c.cloudinaryUrl} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-primary-600">
                    <FiExternalLink />
                  </a>
                  <button onClick={() => onDelete(c._id)} className="text-red-500 hover:text-red-700">
                    <FiTrash2 />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Certificates;
