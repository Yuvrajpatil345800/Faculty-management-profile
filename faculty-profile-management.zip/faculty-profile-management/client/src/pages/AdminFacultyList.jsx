import { useEffect, useState } from 'react';
import { FiSearch, FiTrash2, FiCheckCircle, FiEye, FiEdit2 } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import api from '../services/api';
import Spinner from '../components/Spinner';
import EmptyState from '../components/EmptyState';
import Modal from '../components/Modal';

const DEPARTMENTS = ['Computer Science', 'Information Technology', 'Electronics', 'Mechanical', 'Civil', 'Electrical', 'Mathematics', 'Physics', 'Chemistry', 'MBA'];
const DESIGNATIONS = ['Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'HOD'];

// Admin page: search, filter, view, verify, edit, delete faculty
const AdminFacultyList = () => {
  const [faculty, setFaculty] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('');
  const [designation, setDesignation] = useState('');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [editTarget, setEditTarget] = useState(null);

  const fetchFaculty = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/admin/faculty', {
        params: { search, department, designation, page, limit: 10 },
      });
      setFaculty(data.data);
      setPages(data.pages);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFaculty();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, department, designation, page]);

  const toggleVerify = async (f) => {
    try {
      await api.put(`/admin/faculty/${f._id}`, { isVerified: !f.isVerified });
      toast.success(`Faculty ${!f.isVerified ? 'verified' : 'unverified'}`);
      fetchFaculty();
    } catch (error) {
      toast.error('Update failed');
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this faculty member? This cannot be undone.')) return;
    try {
      await api.delete(`/admin/faculty/${id}`);
      toast.success('Faculty deleted');
      fetchFaculty();
    } catch (error) {
      toast.error('Delete failed');
    }
  };

  const onEditSave = async (formData) => {
    try {
      await api.put(`/admin/faculty/${editTarget._id}`, formData);
      toast.success('Faculty updated');
      setEditTarget(null);
      fetchFaculty();
    } catch (error) {
      toast.error('Update failed');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Manage Faculty</h2>

      {/* Filters */}
      <div className="card flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-[200px]">
          <label className="label">Search</label>
          <div className="relative">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input className="input-field pl-9" placeholder="Name or email..." value={search} onChange={(e) => { setPage(1); setSearch(e.target.value); }} />
          </div>
        </div>
        <div>
          <label className="label">Department</label>
          <select className="input-field" value={department} onChange={(e) => { setPage(1); setDepartment(e.target.value); }}>
            <option value="">All</option>
            {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Designation</label>
          <select className="input-field" value={designation} onChange={(e) => { setPage(1); setDesignation(e.target.value); }}>
            <option value="">All</option>
            {DESIGNATIONS.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card p-0 overflow-x-auto">
        {loading ? (
          <Spinner size="lg" />
        ) : faculty.length === 0 ? (
          <EmptyState title="No faculty found" subtitle="Try adjusting your filters." />
        ) : (
          <>
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-700 text-left">
                <tr>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Designation</th>
                  <th className="px-4 py-3">Completion</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {faculty.map((f) => (
                  <tr key={f._id} className="border-t border-gray-100 dark:border-gray-700">
                    <td className="px-4 py-3 font-medium">{f.name}</td>
                    <td className="px-4 py-3 text-gray-500">{f.department}</td>
                    <td className="px-4 py-3 text-gray-500">{f.designation}</td>
                    <td className="px-4 py-3">{f.profileCompletion}%</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${f.isVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                        {f.isVerified ? 'Verified' : 'Pending'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-2">
                      <Link to={`/admin/faculty/${f._id}`} className="text-primary-600 hover:text-primary-800" title="View">
                        <FiEye className="inline" />
                      </Link>
                      <button onClick={() => setEditTarget(f)} className="text-gray-500 hover:text-gray-700" title="Edit">
                        <FiEdit2 className="inline" />
                      </button>
                      <button onClick={() => toggleVerify(f)} className="text-green-600 hover:text-green-800" title="Toggle Verify">
                        <FiCheckCircle className="inline" />
                      </button>
                      <button onClick={() => onDelete(f._id)} className="text-red-500 hover:text-red-700" title="Delete">
                        <FiTrash2 className="inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 text-sm">
              <span className="text-gray-500">Page {page} of {pages}</span>
              <div className="space-x-2">
                <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-secondary disabled:opacity-40">Previous</button>
                <button disabled={page >= pages} onClick={() => setPage((p) => p + 1)} className="btn-secondary disabled:opacity-40">Next</button>
              </div>
            </div>
          </>
        )}
      </div>

      <Modal isOpen={!!editTarget} onClose={() => setEditTarget(null)} title="Edit Faculty">
        {editTarget && (
          <EditFacultyForm faculty={editTarget} onSave={onEditSave} />
        )}
      </Modal>
    </div>
  );
};

// Small inline form component for editing a faculty record via admin
const EditFacultyForm = ({ faculty, onSave }) => {
  const [form, setForm] = useState({
    name: faculty.name,
    department: faculty.department,
    designation: faculty.designation,
    phone: faculty.phone || '',
    status: faculty.status,
  });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(form); }} className="space-y-4">
      <div>
        <label className="label">Name</label>
        <input className="input-field" name="name" value={form.name} onChange={handleChange} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Department</label>
          <select className="input-field" name="department" value={form.department} onChange={handleChange}>
            {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Designation</label>
          <select className="input-field" name="designation" value={form.designation} onChange={handleChange}>
            {DESIGNATIONS.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>
      <div>
        <label className="label">Phone</label>
        <input className="input-field" name="phone" value={form.phone} onChange={handleChange} />
      </div>
      <div>
        <label className="label">Account Status</label>
        <select className="input-field" name="status" value={form.status} onChange={handleChange}>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
      <button type="submit" className="btn-primary w-full">Save Changes</button>
    </form>
  );
};

export default AdminFacultyList;
