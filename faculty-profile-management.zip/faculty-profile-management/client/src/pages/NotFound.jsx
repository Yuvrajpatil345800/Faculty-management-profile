import { Link } from 'react-router-dom';

// 404 error page
const NotFound = () => (
  <div className="min-h-screen flex flex-col items-center justify-center text-center px-4">
    <h1 className="text-6xl font-extrabold text-primary-600">404</h1>
    <p className="text-lg font-medium mt-2">Page not found</p>
    <p className="text-sm text-gray-500 mt-1">The page you're looking for doesn't exist or has been moved.</p>
    <Link to="/" className="btn-primary mt-6">Go Home</Link>
  </div>
);

export default NotFound;
