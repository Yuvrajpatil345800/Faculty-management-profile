import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { FiCamera, FiDownload } from 'react-icons/fi';
import api from '../services/api';
import useAuth from '../hooks/useAuth';
import Spinner from '../components/Spinner';

const DEPARTMENTS = ['Computer Science', 'Information Technology', 'Electronics', 'Mechanical', 'Civil', 'Electrical', 'Mathematics', 'Physics', 'Chemistry', 'MBA'];
const DESIGNATIONS = ['Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'HOD'];
const QUALIFICATIONS = ['PhD', 'M.Tech', 'M.E', 'M.Sc', 'MBA', 'B.Tech', 'B.E', 'Other'];

// Faculty profile management page: personal details, academic details, photo upload
const Profile = () => {
  const { user, updateUserInContext } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [profileData, setProfileData] = useState(null);

  const personalForm = useForm();
  const academicForm = useForm();

  const fetchData = async () => {
    const { data } = await api.get('/faculty/profile');
    setProfileData(data.data);
    personalForm.reset({
      name: data.data.user.name,
      phone: data.data.user.phone,
      department: data.data.user.department,
      designation: data.data.user.designation,
    });
    academicForm.reset({
      qualification: data.data.profile?.qualification,
      specialization: data.data.profile?.specialization,
      experience: data.data.profile?.experience,
      biography: data.data.profile?.biography,
      researchInterest: data.data.profile?.researchInterest?.join(', '),
    });
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSavePersonal = async (formData) => {
    setSaving(true);
    try {
      const { data } = await api.put('/faculty/personal', formData);
      updateUserInContext(data.data);
      toast.success('Personal details updated');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  const onSaveAcademic = async (formData) => {
    setSaving(true);
    try {
      const payload = {
        ...formData,
        researchInterest: formData.researchInterest ? formData.researchInterest.split(',').map((s) => s.trim()) : [],
      };
      await api.put('/faculty/academic', payload);
      toast.success('Academic details updated');
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  const onPhotoChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('photo', file);
    setPhotoUploading(true);
    try {
      const { data } = await api.post('/faculty/photo', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      updateUserInContext({ profilePhoto: data.data });
      toast.success('Profile photo updated');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Photo upload failed');
    } finally {
      setPhotoUploading(false);
    }
  };

  const downloadPDF = async () => {
    try {
      const response = await api.get('/reports/faculty-pdf', { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${user.name.replace(/\s+/g, '_')}_profile.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      toast.error('Failed to download PDF');
    }
  };

  if (loading) return <Spinner size="lg" />;

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">My Profile</h2>
        <button onClick={downloadPDF} className="btn-secondary flex items-center gap-2">
          <FiDownload /> Download PDF
        </button>
      </div>

      {/* Profile Photo */}
      <div className="card flex items-center gap-6">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden flex items-center justify-center">
            {user?.profilePhoto?.url ? (
              <img src={user.profilePhoto.url} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <span className="text-3xl font-bold text-gray-400">{user?.name?.[0]}</span>
            )}
          </div>
          <label className="absolute bottom-0 right-0 bg-primary-600 text-white p-1.5 rounded-full cursor-pointer hover:bg-primary-700">
            <FiCamera size={14} />
            <input type="file" accept="image/*" className="hidden" onChange={onPhotoChange} />
          </label>
        </div>
        <div>
          <p className="font-semibold">{user?.name}</p>
          <p className="text-sm text-gray-500">{user?.email}</p>
          {photoUploading && <p className="text-xs text-primary-600 mt-1">Uploading...</p>}
        </div>
      </div>

      {/* Personal Details */}
      <form onSubmit={personalForm.handleSubmit(onSavePersonal)} className="card space-y-4">
        <h3 className="font-semibold">Personal Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Full Name</label>
            <input className="input-field" {...personalForm.register('name', { required: true })} />
          </div>
          <div>
            <label className="label">Phone</label>
            <input className="input-field" {...personalForm.register('phone')} />
          </div>
          <div>
            <label className="label">Department</label>
            <select className="input-field" {...personalForm.register('department')}>
              {DEPARTMENTS.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Designation</label>
            <select className="input-field" {...personalForm.register('designation')}>
              {DESIGNATIONS.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        </div>
        <button type="submit" disabled={saving} className="btn-primary">Save Personal Details</button>
      </form>

      {/* Academic Details */}
      <form onSubmit={academicForm.handleSubmit(onSaveAcademic)} className="card space-y-4">
        <h3 className="font-semibold">Academic & Professional Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Qualification</label>
            <select className="input-field" {...academicForm.register('qualification')}>
              {QUALIFICATIONS.map((q) => (
                <option key={q} value={q}>{q}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Specialization</label>
            <input className="input-field" {...academicForm.register('specialization')} />
          </div>
          <div>
            <label className="label">Experience (years)</label>
            <input type="number" min="0" className="input-field" {...academicForm.register('experience')} />
          </div>
          <div>
            <label className="label">Research Interests (comma separated)</label>
            <input className="input-field" {...academicForm.register('researchInterest')} />
          </div>
        </div>
        <div>
          <label className="label">Biography</label>
          <textarea rows="4" className="input-field" {...academicForm.register('biography')} />
        </div>
        <button type="submit" disabled={saving} className="btn-primary">Save Academic Details</button>
      </form>
    </div>
  );
};

export default Profile;
