import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { FiArrowLeft, FiCheck, FiX, FiDownload } from 'react-icons/fi';
import api from '../services/api';
import Spinner from '../components/Spinner';
import StatusBadge from '../components/StatusBadge';
import ProfileCompletionBar from '../components/ProfileCompletionBar';

// Admin view of a single faculty's full profile with certificate verification controls
const AdminFacultyDetail = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const { data: res } = await api.get(`/faculty/profile/${id}`);
      setData(res.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const verifyCertificate = async (certId, verificationStatus) => {
    try {
      await api.put(`/certificates/${certId}/verify`, { verificationStatus });
      toast.success(`Certificate ${verificationStatus}`);
      fetchProfile();
    } catch (error) {
      toast.error('Verification failed');
    }
  };

  const downloadPDF = async () => {
    try {
      const response = await api.get(`/reports/faculty-pdf/${id}`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'faculty_profile.pdf');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      toast.error('Download failed');
    }
  };

  if (loading) return <Spinner size="lg" />;
  if (!data) return null;

  const { user, profile, publications, certificates, achievements } = data;

  return (
    <div className="space-y-6 max-w-4xl">
      <Link to="/admin/faculty" className="inline-flex items-center gap-2 text-sm text-primary-600 hover:underline">
        <FiArrowLeft /> Back to Faculty List
      </Link>

      <div className="card flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden flex items-center justify-center">
            {user.profilePhoto?.url ? (
              <img src={user.profilePhoto.url} alt={user.name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xl font-bold text-gray-400">{user.name[0]}</span>
            )}
          </div>
          <div>
            <h2 className="text-lg font-bold">{user.name}</h2>
            <p className="text-sm text-gray-500">{user.designation} • {user.department}</p>
            <p className="text-xs text-gray-400">{user.email}</p>
          </div>
        </div>
        <button onClick={downloadPDF} className="btn-secondary flex items-center gap-2">
          <FiDownload /> Download Profile PDF
        </button>
      </div>

      <div className="card max-w-sm">
        <ProfileCompletionBar percentage={user.profileCompletion} />
      </div>

      <div className="card">
        <h3 className="font-semibold mb-3">Academic Details</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <p><span className="text-gray-400">Qualification:</span> {profile?.qualification || 'N/A'}</p>
          <p><span className="text-gray-400">Specialization:</span> {profile?.specialization || 'N/A'}</p>
          <p><span className="text-gray-400">Experience:</span> {profile?.experience || 0} years</p>
        </div>
        {profile?.biography && <p className="text-sm text-gray-500 mt-3">{profile.biography}</p>}
      </div>

      <div className="card">
        <h3 className="font-semibold mb-3">Certificates ({certificates.length})</h3>
        {certificates.length === 0 ? (
          <p className="text-sm text-gray-400">No certificates uploaded.</p>
        ) : (
          <ul className="divide-y divide-gray-100 dark:divide-gray-700">
            {certificates.map((c) => (
              <li key={c._id} className="flex items-center justify-between py-3">
                <div>
                  <a href={c.cloudinaryUrl} target="_blank" rel="noreferrer" className="font-medium text-sm hover:underline">
                    {c.certificateName}
                  </a>
                  <div className="mt-1"><StatusBadge status={c.verificationStatus} /></div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => verifyCertificate(c._id, 'approved')} className="p-2 rounded-lg bg-green-50 text-green-600 hover:bg-green-100" title="Approve">
                    <FiCheck />
                  </button>
                  <button onClick={() => verifyCertificate(c._id, 'rejected')} className="p-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-100" title="Reject">
                    <FiX />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="card">
        <h3 className="font-semibold mb-3">Publications ({publications.length})</h3>
        {publications.length === 0 ? (
          <p className="text-sm text-gray-400">No publications added.</p>
        ) : (
          <ul className="text-sm space-y-2">
            {publications.map((p) => (
              <li key={p._id}>• {p.title} - {p.journal || p.publisher} ({p.year})</li>
            ))}
          </ul>
        )}
      </div>

      <div className="card">
        <h3 className="font-semibold mb-3">Achievements ({achievements.length})</h3>
        {achievements.length === 0 ? (
          <p className="text-sm text-gray-400">No achievements added.</p>
        ) : (
          <ul className="text-sm space-y-2">
            {achievements.map((a) => (
              <li key={a._id}>• {a.title} ({a.year})</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default AdminFacultyDetail;
