import { useState } from 'react';
import toast from 'react-hot-toast';
import { FiDownload, FiFileText } from 'react-icons/fi';
import api from '../services/api';

const DEPARTMENTS = ['Computer Science', 'Information Technology', 'Electronics', 'Mechanical', 'Civil', 'Electrical', 'Mathematics', 'Physics', 'Chemistry', 'MBA'];

// Admin reports page: department reports and CSV export
const AdminReports = () => {
  const [dept, setDept] = useState(DEPARTMENTS[0]);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const generateReport = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/reports/department/${dept}`);
      setReport(data.data);
    } catch (error) {
      toast.error('Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  const exportCSV = async () => {
    try {
      const response = await api.get('/reports/export-csv', { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'faculty_report.csv');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      toast.error('Export failed');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Reports</h2>

      <div className="card">
        <h3 className="font-semibold mb-4 flex items-center gap-2"><FiFileText /> Export All Faculty (CSV)</h3>
        <p className="text-sm text-gray-500 mb-4">Download a spreadsheet containing all faculty records for offline use.</p>
        <button onClick={exportCSV} className="btn-primary flex items-center gap-2">
          <FiDownload /> Export CSV
        </button>
      </div>

      <div className="card">
        <h3 className="font-semibold mb-4">Department-wise Report</h3>
        <div className="flex items-end gap-3 mb-4">
          <div className="flex-1">
            <label className="label">Department</label>
            <select className="input-field" value={dept} onChange={(e) => setDept(e.target.value)}>
              {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <button onClick={generateReport} disabled={loading} className="btn-primary">
            {loading ? 'Generating...' : 'Generate Report'}
          </button>
        </div>

        {report && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-700 text-left">
                <tr>
                  <th className="px-4 py-2">Name</th>
                  <th className="px-4 py-2">Designation</th>
                  <th className="px-4 py-2">Completion</th>
                  <th className="px-4 py-2">Verified</th>
                  <th className="px-4 py-2">Publications</th>
                  <th className="px-4 py-2">Certificates</th>
                </tr>
              </thead>
              <tbody>
                {report.map((r, i) => (
                  <tr key={i} className="border-t border-gray-100 dark:border-gray-700">
                    <td className="px-4 py-2 font-medium">{r.name}</td>
                    <td className="px-4 py-2">{r.designation}</td>
                    <td className="px-4 py-2">{r.profileCompletion}%</td>
                    <td className="px-4 py-2">{r.isVerified ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-2">{r.publications}</td>
                    <td className="px-4 py-2">{r.certificates}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {report.length === 0 && <p className="text-sm text-gray-400 py-4">No faculty found in this department.</p>}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminReports;
