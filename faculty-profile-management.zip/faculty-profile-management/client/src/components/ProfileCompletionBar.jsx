// Visual progress bar showing profile completion percentage
const ProfileCompletionBar = ({ percentage = 0 }) => {
  const color = percentage < 40 ? 'bg-red-500' : percentage < 75 ? 'bg-yellow-500' : 'bg-green-500';
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span className="text-gray-500 dark:text-gray-400">Profile Completion</span>
        <span className="font-semibold">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
        <div className={`${color} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
};

export default ProfileCompletionBar;
