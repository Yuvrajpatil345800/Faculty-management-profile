import { NavLink } from 'react-router-dom';
import {
  FiGrid,
  FiUser,
  FiBookOpen,
  FiAward,
  FiFileText,
  FiUsers,
  FiBarChart2,
  FiPieChart,
} from 'react-icons/fi';
import useAuth from '../hooks/useAuth';

// Side navigation, links vary by role (faculty vs admin)
const Sidebar = () => {
  const { user } = useAuth();

  const facultyLinks = [
    { to: '/dashboard', label: 'Dashboard', icon: FiGrid },
    { to: '/profile', label: 'My Profile', icon: FiUser },
    { to: '/publications', label: 'Publications', icon: FiBookOpen },
    { to: '/certificates', label: 'Certificates', icon: FiFileText },
    { to: '/achievements', label: 'Achievements', icon: FiAward },
  ];

  const adminLinks = [
    { to: '/admin/dashboard', label: 'Analytics', icon: FiPieChart },
    { to: '/admin/faculty', label: 'Manage Faculty', icon: FiUsers },
    { to: '/admin/reports', label: 'Reports', icon: FiBarChart2 },
  ];

  const links = user?.role === 'admin' ? adminLinks : facultyLinks;

  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-100 dark:border-gray-700 h-screen sticky top-0 flex flex-col">
      <div className="h-16 flex items-center px-6 border-b border-gray-100 dark:border-gray-700">
        <span className="font-bold text-primary-700 dark:text-primary-400 text-lg">FacultyHub</span>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1">
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/40 dark:text-primary-300'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
