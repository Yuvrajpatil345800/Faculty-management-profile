// Displayed when a list/table has no data to show
const EmptyState = ({ title = 'No data found', subtitle = 'Get started by adding a new item.', icon: Icon }) => (
  <div className="flex flex-col items-center justify-center py-12 text-center">
    {Icon && <Icon className="text-4xl text-gray-300 dark:text-gray-600 mb-3" />}
    <p className="font-semibold text-gray-600 dark:text-gray-300">{title}</p>
    <p className="text-sm text-gray-400 dark:text-gray-500">{subtitle}</p>
  </div>
);

export default EmptyState;
