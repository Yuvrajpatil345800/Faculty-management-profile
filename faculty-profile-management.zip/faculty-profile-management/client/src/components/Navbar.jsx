import { useState, useEffect } from 'react';
import { FiSun, FiMoon, FiLogOut, FiUser } from 'react-icons/fi';
import useAuth from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';

// Top navigation bar with theme toggle and user menu
const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('theme');
    const isDark = stored === 'dark';
    setDark(isDark);
    document.documentElement.classList.toggle('dark', isDark);
  }, []);

  const toggleTheme = () => {
    const newDark = !dark;
    setDark(newDark);
    document.documentElement.classList.toggle('dark', newDark);
    localStorage.setItem('theme', newDark ? 'dark' : 'light');
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="h-16 flex items-center justify-between px-6 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 sticky top-0 z-10">
      <h1 className="font-semibold text-lg text-gray-800 dark:text-gray-100">
        {user?.role === 'admin' ? 'Admin Console' : 'Faculty Portal'}
      </h1>
      <div className="flex items-center gap-4">
        <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
          {dark ? <FiSun /> : <FiMoon />}
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center overflow-hidden">
            {user?.profilePhoto?.url ? (
              <img src={user.profilePhoto.url} alt={user.name} className="w-full h-full object-cover" />
            ) : (
              <FiUser className="text-primary-600 dark:text-primary-300" />
            )}
          </div>
          <span className="text-sm font-medium hidden sm:block">{user?.name}</span>
        </div>
        <button onClick={handleLogout} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-red-500" title="Logout">
          <FiLogOut />
        </button>
      </div>
    </header>
  );
};

export default Navbar;
