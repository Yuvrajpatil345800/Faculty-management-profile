import { Outlet } from 'react-router-dom';

// Layout for login/register pages: centered card on a branded background
const AuthLayout = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-primary-100 dark:from-gray-900 dark:to-gray-800 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-primary-800 dark:text-primary-300">FacultyHub</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Cloud-Based Faculty Profile Management System</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;
