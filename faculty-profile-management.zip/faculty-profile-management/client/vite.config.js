import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the React client
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
  },
});
